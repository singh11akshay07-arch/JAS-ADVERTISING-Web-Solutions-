JAS Advertising and Web Solutions — Version 2

Cloudflare Pages deployment:
1. Extract this ZIP file.
2. Upload the extracted site files to Cloudflare Pages, or connect the folder/repository.
3. Ensure index.html is at the project root.

Included files:
- index.html
- jas-logo.png (original logo retained unchanged)
- silver.package.png
- gold.Package.png
- platinum.package.png
- Diamond.package.png

The four supplied package images are included in their original form.
